<?php
/**
 * @package     Joomla - > Site and Administrator payment info
 * @subpackage  com_tinypayment
 * @copyright   trangell team => https://trangell.com
 * @copyright   Copyright (C) 2017 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('_JEXEC') or die;
jimport('joomla.application.component.model');
JModelLegacy::addIncludePath(JPATH_SITE.'/components/com_tinypayment/models'); 
require_once JPATH_SITE .'/components/com_tinypayment/helpers/otherport.php'; 
require_once JPATH_SITE .'/components/com_tinypayment/helpers/inputcheck.php'; 
//---------------------------------------- config 
require_once JPATH_SITE .'/administrator/components/com_tinypayment/helpers/config.php'; 
//----------------------------------------

class sn{
	static function send ($uniqId,$price,$port,$payDescription,$payerEmail,$payerMobile) {
		//------------------------ config
		$mconfig = new config();
		$loadMainConfig = $mconfig->loadMainSettings();
		$port_sn = $mconfig->loadPortSettings(3);
		//$port_sn = $config->loadPortSettings(3);
		//------------------------
		$app	= JFactory::getApplication();
		if ($port_sn->terminal_code != null){
			$Model = JModelLegacy::getInstance( 'Form', 'TinyPaymentModel' );
			$session = JFactory::getSession();
			
			$MerchantID = $port_sn->terminal_code;
			
			
			$Amount = ($price/10); //Amount will be based on Toman - Required
			$Description = $payDescription; // Required
			$Email = $payerEmail; // Optional
			$Mobile = $payerMobile; // Optional
			$CallbackURL = JURI::root().'index.php?option=com_tinypayment&view=form&layout=callback&task=form.callback'; // Required
			
			
			try {
			
			
if ($port_sn->test_mode != null && $port_sn->test_mode == 1){
			
			
	            	$data_string = json_encode(array(
					'pin'=> $MerchantID,
					'price'=> ceil($Amount),
					'callback'=>$CallbackURL,
					'order_id'=> 123456789,
					'email'=> $Email,
					'description'=> $Description,
					'mobile'=>  $Mobile,
					'ip'=> $_SERVER['REMOTE_ADDR'],
					'callback_type'=>2
					));

}
else{
	
	$data_string = json_encode(array(
					'pin'=> $MerchantID,
					'price'=> ceil($Amount),
					'callback'=>$CallbackURL,
					'order_id'=> 123456789,
					'description'=> $Description,
					'ip'=> $_SERVER['REMOTE_ADDR'],
					'callback_type'=>2
					));
	
}

	          $ch = curl_init('https://developerapi.net/api/v1/request');
					curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
					curl_setopt($ch, CURLOPT_HTTPHEADER, array(
					'Content-Type: application/json',
					'Content-Length: ' . strlen($data_string))
					);
					curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
					curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 20);
					$result = curl_exec($ch);
					curl_close($ch);
					$json = json_decode($result,true);
					



					
						 $res=$json['result'];
                 
	                 switch ($res) {
						    case -1:
						    $msg = "پارامترهای ارسالی برای متد مورد نظر ناقص یا خالی هستند . پارمترهای اجباری باید ارسال گردد";
						    break;
						     case -2:
						    $msg = "دسترسی api برای شما مسدود است";
						    break;
						     case -6:
						    $msg = "عدم توانایی اتصال به گیت وی بانک از سمت وبسرویس";
						    break;

						     case -9:
						    $msg = "خطای ناشناخته";
						    break;

						     case -20:
						    $msg = "پین نامعتبر";
						    break;
						     case -21:
						    $msg = "ip نامعتبر";
						    break;

						     case -22:
						    $msg = "مبلغ وارد شده کمتر از حداقل مجاز میباشد";
						    break;


						    case -23:
						    $msg = "مبلغ وارد شده بیشتر از حداکثر مبلغ مجاز هست";
						    break;
						    
						      case -24:
						    $msg = "مبلغ وارد شده نامعتبر";
						    break;
						    
						      case -26:
						    $msg = "درگاه غیرفعال است";
						    break;
						    
						      case -27:
						    $msg = "آی پی مسدود شده است";
						    break;
						    
						      case -28:
						    $msg = "آدرس کال بک نامعتبر است ، احتمال مغایرت با آدرس ثبت شده";
						    break;
						    
						      case -29:
						    $msg = "آدرس کال بک خالی یا نامعتبر است";
						    break;
						    
						      case -30:
						    $msg = "چنین تراکنشی یافت نشد";
						    break;
						    
						      case -31:
						    $msg = "تراکنش ناموفق است";
						    break;
						    
						      case -32:
						    $msg = "مغایرت مبالغ اعلام شده با مبلغ تراکنش";
						    break;
						 
						    
						      case -35:
						    $msg = "شناسه فاکتور اعلامی order_id نامعتبر است";
						    break;
						    
						      case -36:
						    $msg = "پارامترهای برگشتی بانک bank_return نامعتبر است";
						    break;
						        case -38:
						    $msg = "تراکنش برای چندمین بار وریفای شده است";
						    break;
						    
						      case -39:
						    $msg = "تراکنش در حال انجام است";
						    break;
						    
                            case 1:
						    $msg = "پرداخت با موفقیت انجام گردید.";
						    break;

						    default:
						       $msg = $json['msg'];
						}
						






			if(!empty($json['result']) AND $json['result'] == 1)
					{ 
				

						session_start();
										// Set Session
						$_SESSION[$sec] = [
							'price'=>$Amount ,
							'order_id'=>$order_id ,
							'au'=>$json['au'] ,
						];
						

									echo "<div style='display:none'>{$json['form']}</div>Please wait ... <script language='javascript'>document.payment.submit(); </script>";
 
					
				} 
				else {
					echo'ERR: '.$msg;
				}
			}
			catch(\SoapFault $e) {
				$app	= JFactory::getApplication();
				$link = JRoute::_('index.php?option=com_tinypayment&view=form&layout=default',false);
				$app->redirect($link, '<h2>خطا غیر منتظره رخ داده است</h2>', $msgType='Error'); 
			}
		}
		else {
			$app	= JFactory::getApplication();
			$link = JRoute::_('index.php?option=com_tinypayment&view=form&layout=default',false);
			$app->redirect($link, '<h2>یک یا چند پیکربندی از افزونه بدرستی انجام نشده است.</h2>', $msgType='Error'); 
		     }
	}
	
	static function verify ($uniqId,$portId,$price) {
	

		$app = JFactory::getApplication(); 
		$jinput = $app->input;
		//------------------------ config
		$mconfig = new config();
		$loadMainConfig = $mconfig->loadMainSettings();
		$port_sn = $mconfig->loadPortSettings(3);
		//------------------------
		$Authority = $jinput->get->get('Authority', '0', 'INT');
		$status = $jinput->get->get('Status', '', 'STRING');

		if ($port_sn->terminal_code != null){
			$Model = JModelLegacy::getInstance( 'Form', 'TinyPaymentModel' );
			$session = JFactory::getSession();
			
			if (other::checkBot($uniqId)){	


				
					$MerchantID = $port_sn->terminal_code;
				
				$Amount = $price/10; //Amount will be based on Toman

				

					try {

					


                                    $bank_return = $_POST + $_GET ;
									$data_string = json_encode(array (
									'pin' => $MerchantID,
									'price' => ceil($Amount),
									'order_id' => 123456789,
									'au' => $_SESSION[$sec]['au'],
									'bank_return' =>$bank_return,
									));



	                                $ch = curl_init('https://developerapi.net/api/v1/verify');
									curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
									curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
									curl_setopt($ch, CURLOPT_HTTPHEADER, array(
									'Content-Type: application/json',
									'Content-Length: ' . strlen($data_string))
									);
									curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
									curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 20);
									$result = curl_exec($ch);
									curl_close($ch);
									$json = json_decode($result,true);
								

		
						 $res=$json['result'];
                 
	                 switch ($res) {
						    case -1:
						    $msg = "پارامترهای ارسالی برای متد مورد نظر ناقص یا خالی هستند . پارمترهای اجباری باید ارسال گردد";
						    break;
						     case -2:
						    $msg = "دسترسی api برای شما مسدود است";
						    break;
						     case -6:
						    $msg = "عدم توانایی اتصال به گیت وی بانک از سمت وبسرویس";
						    break;

						     case -9:
						    $msg = "خطای ناشناخته";
						    break;

						     case -20:
						    $msg = "پین نامعتبر";
						    break;
						     case -21:
						    $msg = "ip نامعتبر";
						    break;

						     case -22:
						    $msg = "مبلغ وارد شده کمتر از حداقل مجاز میباشد";
						    break;


						    case -23:
						    $msg = "مبلغ وارد شده بیشتر از حداکثر مبلغ مجاز هست";
						    break;
						    
						      case -24:
						    $msg = "مبلغ وارد شده نامعتبر";
						    break;
						    
						      case -26:
						    $msg = "درگاه غیرفعال است";
						    break;
						    
						      case -27:
						    $msg = "آی پی مسدود شده است";
						    break;
						    
						      case -28:
						    $msg = "آدرس کال بک نامعتبر است ، احتمال مغایرت با آدرس ثبت شده";
						    break;
						    
						      case -29:
						    $msg = "آدرس کال بک خالی یا نامعتبر است";
						    break;
						    
						      case -30:
						    $msg = "چنین تراکنشی یافت نشد";
						    break;
						    
						      case -31:
						    $msg = "تراکنش ناموفق است";
						    break;
						    
						      case -32:
						    $msg = "مغایرت مبالغ اعلام شده با مبلغ تراکنش";
						    break;
						 
						    
						      case -35:
						    $msg = "شناسه فاکتور اعلامی order_id نامعتبر است";
						    break;
						    
						      case -36:
						    $msg = "پارامترهای برگشتی بانک bank_return نامعتبر است";
						    break;
						        case -38:
						    $msg = "تراکنش برای چندمین بار وریفای شده است";
						    break;
						    
						      case -39:
						    $msg = "تراکنش در حال انجام است";
						    break;
						    
                            case 1:
						    $msg = "پرداخت با موفقیت انجام گردید.";
						    break;

						    default:
						       $msg = $json['msg'];
						}
						




						$resultStatus = abs($result->Status); // tabdli add manfi be mosbat
						if( ! empty($json['result']) and $json['result'] == 1){
                            $msg2="پرداخت با موفقیت انجام شد";
							$msg= $Model->getTinyMsg($portId,$resultStatus); //get message from DB
							$Model->updateLogs($uniqId,$resultStatus,"پرداخت با موفقیت انجام شد"); // update transcation logs
							$Model->updateTransactions($uniqId,$Authority,$result->RefID,''); // update transcation
							$link = JRoute::_('index.php?option=com_tinypayment&view=form&layout=callback',false);
							$app->redirect($link, '<h2>'.$msg2.'</h2>', $msgType='Message'); 
						} 
						else {
							$msg2="پرداخت انجام نشد";
							$msg3= $Model->getTinyMsg($portId,$resultStatus);
							$Model->updateLogs($uniqId,$resultStatus,"پرداخت انجام نشد"); // update transcation logs
							$Model->updateTransactions($uniqId,$Authority,$result->RefID,''); // update transcation
							$link = JRoute::_('index.php?option=com_tinypayment&view=form&layout=default',false);
							$app->redirect($link, '<h2>'.$msg.'</h2>', $msgType='Error'); 
						}
					}
					catch(\SoapFault $e) {
						$app	= JFactory::getApplication();
						$link = JRoute::_('index.php?option=com_tinypayment&view=form&layout=default',false);
						$app->redirect($link, '<h2>خطا غیر منتظره رخ داده است</h2>', $msgType='Error'); 
					}
			
			}
			else {
				other::hack($uniqId);
			}
		}
		else {
			$app	= JFactory::getApplication();
			$link = JRoute::_('index.php?option=com_tinypayment&view=form&layout=default',false);
			$app->redirect($link, '<h2>یک یا چند پیکربندی از افزونه بدرستی انجام نشده است.</h2>', $msgType='Error'); 
		}
	}
}

?>
