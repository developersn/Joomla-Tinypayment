<?php
//============================================================+
// File name   : eng.php
// Begin       : 2004-03-03
// Last Update : 2010-10-26
//
// Description : Language module for TCPDF
//               (contains translated texts)
//               English
//
// Author: Nicola Asuni
//
// (c) Copyright:
//               Nicola Asuni
//               Tecnick.com LTD
//               www.tecnick.com
//               info@tecnick.com
//============================================================+
//============================================================+
// File name   : tcpdf.php
// Version     : 6.2.12
// Begin       : 2002-08-03
// Last Update : 2015-06-18
// Author      : Nicola Asuni - Tecnick.com LTD - www.tecnick.com - info@tecnick.com
// License     : GNU-LGPL v3 (http://www.gnu.org/copyleft/lesser.html)
// -------------------------------------------------------------------
/**
 * TCPDF language file (contains translated texts).
 * @package com.tecnick.tcpdf
 * @brief TCPDF language file: English
 * @author Nicola Asuni
 * @since 2004-03-03
 */
defined('_JEXEC') or die;
// English

global $l;
$l = Array();

// PAGE META DESCRIPTORS --------------------------------------

$l['a_meta_charset'] = 'UTF-8';
$l['a_meta_dir'] = 'ltr';
$l['a_meta_language'] = 'en';

// TRANSLATIONS --------------------------------------
$l['w_page'] = 'page';

//============================================================+
// END OF FILE
//============================================================+
