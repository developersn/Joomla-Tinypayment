<?php
/**
 * @package     Joomla - > Site and Administrator payment info
 * @subpackage  com_tinypayment
 * @copyright   trangell team => https://trangell.com
 * @copyright   Copyright (C) 2017 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted Access');
JHtml::stylesheet(JURI::root().'components/com_tinypayment/ui/dist/css/customadmin.css');
JHtml::stylesheet(JURI::root().'components/com_tinypayment/ui/dist/css/custom.css');
JHtml::_('behavior.formvalidation');
JHtml::script('https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.2.2/Chart.bundle.js');
JHtml::stylesheet('https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css');
require_once JPATH_SITE .'/administrator/components/com_tinypayment/helpers/jdf.php';
require_once JPATH_SITE .'/administrator/components/com_tinypayment/helpers/config.php';

$app = JFactory::getApplication('site');
$id = $app->input->getInt('id');  
$user = JFactory::getUser();

$config = new config();
$settings = $config->loadMainSettings();
$port_mellat = $config->loadPortSettings(1);
$port_saman = $config->loadPortSettings(9);
$port_sn = $config->loadPortSettings(3);

?>
<form action="<?php echo JRoute::_('index.php?option=com_tinypayment&view=settings'); ?>" method="post" name="adminForm" id="adminForm" class="form-validate">
<div class="form-group">
<?php echo JHtml::_('bootstrap.startTabSet', 'main', array('active' => 'main_settings')); ?>

  <?php echo JHtml::_('bootstrap.addTab', 'main', 'main_settings', JText::_('&#1578;&#1606;&#1592;&#1740;&#1605;&#1575;&#1578; &#1589;&#1601;&#1581;&#1607;', true)); ?>
               
            
  <h5>&#1586;&#1605;&#1575;&#1606; &#1576;&#1585;&#1711;&#1588;&#1578;</h5>

    <input name="time_back" id="time_back" value="<? echo htmlspecialchars($settings->time_back, ENT_COMPAT, 'UTF-8'); ?>" class="required form-control" required="required" aria-required="true" aria-invalid="false" type="text">

    <div class="alert ">
      &#1586;&#1605;&#1575;&#1606;&#1740; &#1705;&#1607; &#1588;&#1605;&#1575; &#1606;&#1740;&#1575;&#1586; &#1583;&#1575;&#1585;&#1740;&#1583; &#1705;&#1575;&#1585;&#1576;&#1585; &#1576;&#1607; &#1576;&#1575;&#1606;&#1705; &#1576;&#1585;&#1608;&#1583; &#1608; &#1576;&#1607; &#1587;&#1575;&#1740;&#1578; &#1576;&#1585;&#1711;&#1585;&#1583;&#1583;. &#1576;&#1607; &#1589;&#1608;&#1585;&#1578; &#1662;&#1740;&#1588;&#1601;&#1585;&#1590; &#1585;&#1608;&#1740; &#1777;&#1776; &#1583;&#1602;&#1740;&#1602;&#1607; &#1605;&#1740; &#1576;&#1575;&#1588;&#1583; &#1576;&#1740;&#1588;&#1578;&#1585; &#1575;&#1586; &#1570;&#1606; &#1605;&#1740; &#1578;&#1608;&#1575;&#1606;&#1583; &#1605;&#1588;&#1705;&#1604;&#1575;&#1578; &#1575;&#1605;&#1606;&#1740;&#1578;&#1740; &#1576;&#1585;&#1575;&#1740; &#1588;&#1605;&#1575; &#1583;&#1585;&#1587;&#1578; &#1705;&#1606;&#1583;
    </div>
  <hr>
  <h5>&#1606;&#1605;&#1575;&#1740;&#1588; pdf</h5>
  <label class="radio-inline">
  <input type="radio" name="show_pdf" value="1" <?php echo ($settings->show_pdf) == 1 ? 'checked="checked"' : ''; ?>> &#1576;&#1604;&#1607;
  </label>
  <label class="radio-inline">
  <input type="radio" name="show_pdf" value="0" <?php echo ($settings->show_pdf) == 0 ? 'checked="checked"' : ''; ?>> &#1582;&#1740;&#1585;
  </label>
  <div class="clearfix"></div>
  <br>
  <div class="alert ">
      &#1575;&#1740;&#1606; &#1578;&#1606;&#1592;&#1740;&#1605;&#1575;&#1578; &#1576;&#1585;&#1575;&#1740; &#1606;&#1605;&#1575;&#1740;&#1588; &#1583;&#1575;&#1583;&#1606; &#1740;&#1575; &#1606;&#1605;&#1575;&#1740;&#1588; &#1606;&#1583;&#1575;&#1583;&#1606; &#1583;&#1705;&#1605;&#1607; &#1582;&#1585;&#1608;&#1580;&#1740;  PDF &#1583;&#1585; &#1740;&#1705; &#1601;&#1575;&#1705;&#1578;&#1608;&#1585; &#1605;&#1740; &#1576;&#1575;&#1588;&#1583; . &#1588;&#1605;&#1575; &#1605;&#1740; &#1578;&#1608;&#1575;&#1606;&#1740;&#1583; &#1575;&#1740;&#1606; &#1605;&#1608;&#1585;&#1583; &#1585;&#1575; &#1601;&#1593;&#1575;&#1604; &#1740;&#1575; &#1594;&#1740;&#1585; &#1601;&#1593;&#1575;&#1604; &#1705;&#1606;&#1740;&#1583;
  </div>
  <hr>             
                <h5>&#1608;&#1590;&#1593;&#1740;&#1578; &#1705;&#1583; &#1705;&#1662;&#1670;&#1575;&#1740; &#1711;&#1608;&#1711;&#1604; </h5>
                <input type="radio" name="captcha" value="1" <? echo ($settings->captcha) == 1 ? 'checked="checked"' : ''; ?>> &#1576;&#1604;&#1607; 
                <input type="radio" name="captcha" value="0" <? echo ($settings->captcha) == 0 ? 'checked="checked"' : ''; ?>> &#1582;&#1740;&#1585;
<br>
<br>
                &#1705;&#1604;&#1740;&#1583; &#1593;&#1605;&#1608;&#1605;&#1740; <input name="public_key" id="public_key" value="<? echo htmlspecialchars($settings->public_key, ENT_COMPAT, 'UTF-8'); ?>" class="required" required="required" aria-required="true" aria-invalid="false" type="text"><p>
                &#1705;&#1604;&#1740;&#1583; &#1582;&#1589;&#1608;&#1589;&#1740; <input name="private_key" id="private_key" value="<? echo htmlspecialchars($settings->private_key, ENT_COMPAT, 'UTF-8'); ?>" class="required" required="required" aria-required="true" aria-invalid="false" type="text"><p>
      <div class="alert ">
      &#1705;&#1583; &#1705;&#1662;&#1670;&#1575; &#1576;&#1585;&#1575;&#1740; &#1580;&#1604;&#1608;&#1711;&#1740;&#1585;&#1740; &#1575;&#1586; &#1581;&#1605;&#1604;&#1575;&#1578; &#1585;&#1576;&#1575;&#1578; &#1607;&#1575; &#1576;&#1607; &#1601;&#1585;&#1605; &#1583;&#1585; &#1608;&#1576; &#1587;&#1575;&#1740;&#1578; &#1588;&#1605;&#1575; &#1605;&#1740; &#1576;&#1575;&#1588;&#1583; . &#1605;&#1575; &#1576;&#1585;&#1575;&#1740; &#1575;&#1605;&#1606;&#1740;&#1578; &#1576;&#1740;&#1588;&#1578;&#1585; &#1575;&#1586; &#1587;&#1740;&#1587;&#1578;&#1605; reCaptcha &#1711;&#1608;&#1711;&#1604; &#1575;&#1587;&#1578;&#1601;&#1575;&#1583;&#1607; &#1705;&#1585;&#1583;&#1740;&#1605; . &#1576;&#1585;&#1575;&#1740; &#1583;&#1585;&#1740;&#1575;&#1601;&#1578; &#1705;&#1583; &#1593;&#1605;&#1608;&#1605;&#1740; &#1608; &#1582;&#1589;&#1608;&#1589;&#1740; &#1605;&#1740; &#1578;&#1608;&#1575;&#1606;&#1740;&#1583; &#1576;&#1607; &#1608;&#1576; &#1587;&#1575;&#1740;&#1578; google.com/recaptcha &#1605;&#1585;&#1575;&#1580;&#1593;&#1607; &#1705;&#1606;&#1740;&#1583;
      </div>
<hr> 
  <h5>&#1606;&#1605;&#1575;&#1740;&#1588; &#1575;&#1740;&#1605;&#1740;&#1604; </h5>
                <input type="radio" name="show_email" value="1" <? echo ($settings->show_email) == 1 ? 'checked="checked"' : ''; ?>> &#1576;&#1604;&#1607;
                <input type="radio" name="show_email" value="0" <? echo ($settings->show_email) == 0 ? 'checked="checked"' : ''; ?>> &#1582;&#1740;&#1585;
<div class="clearfix"></div>
<br>
<div class="alert ">
      &#1575;&#1740;&#1606; &#1578;&#1606;&#1592;&#1740;&#1605;&#1575;&#1578; &#1576;&#1585;&#1575;&#1740; &#1606;&#1605;&#1575;&#1740;&#1588; &#1583;&#1575;&#1583;&#1606; &#1740;&#1575; &#1606;&#1605;&#1575;&#1740;&#1588; &#1606;&#1583;&#1575;&#1583;&#1606; &#1583;&#1705;&#1605;&#1607; &#1582;&#1585;&#1608;&#1580;&#1740;  email &#1583;&#1585; &#1740;&#1705; &#1601;&#1575;&#1705;&#1578;&#1608;&#1585; &#1605;&#1740; &#1576;&#1575;&#1588;&#1583; . &#1588;&#1605;&#1575; &#1605;&#1740; &#1578;&#1608;&#1575;&#1606;&#1740;&#1583; &#1575;&#1740;&#1606; &#1605;&#1608;&#1585;&#1583; &#1585;&#1575; &#1601;&#1593;&#1575;&#1604; &#1740;&#1575; &#1594;&#1740;&#1585; &#1601;&#1593;&#1575;&#1604; &#1705;&#1606;&#1740;&#1583;
  </div>
<hr>                
  <h5> &#1576;&#1608;&#1578; &#1575;&#1587;&#1578;&#1585;&#1662; </h5>
                <input type="radio" name="bootstrap" value="1" <? echo ($settings->bootstrap) == 1 ? 'checked="checked"' : ''; ?>> &#1576;&#1604;&#1607; 
                <input type="radio" name="bootstrap" value="0" <? echo ($settings->bootstrap) == 0 ? 'checked="checked"' : ''; ?>> &#1582;&#1740;&#1585; 
             <div class="clearfix"></div>
             <br> 
         <div class="alert ">
&#1578;&#1608;&#1580;&#1607; : &#1605;&#1578;&#1575;&#1587;&#1601;&#1575;&#1606;&#1607; &#1607;&#1606;&#1608;&#1586; &#1582;&#1740;&#1604;&#1740; &#1575;&#1586; &#1705;&#1575;&#1585;&#1576;&#1585;&#1575;&#1606; &#1580;&#1608;&#1605;&#1604;&#1575;&#1740;&#1740; &#1575;&#1586; &#1602;&#1575;&#1604;&#1576; &#1607;&#1575;&#1740; &#1578;&#1575;&#1585;&#1740;&#1582; &#1711;&#1584;&#1588;&#1578;&#1607; &#1575;&#1587;&#1578;&#1601;&#1575;&#1583;&#1607; &#1605;&#1740; &#1705;&#1606;&#1606;&#1583; &#1608; &#1576;&#1607; &#1607;&#1605;&#1740;&#1606; &#1578;&#1585;&#1578;&#1740;&#1576; &#1583;&#1585; &#1575;&#1740;&#1606; &#1602;&#1575;&#1604;&#1576; &#1607;&#1575; &#1601;&#1585;&#1740;&#1605; &#1608;&#1585;&#1705; &#1576;&#1608;&#1578;&#1587;&#1578;&#1585;&#1662; &#1608;&#1580;&#1608;&#1583; &#1606;&#1583;&#1575;&#1585;&#1583; &#1608; &#1588;&#1605;&#1575;&#1740;&#1604; &#1575;&#1601;&#1586;&#1608;&#1606;&#1607; &#1605;&#1584;&#1705;&#1608;&#1585; &#1576;&#1607; &#1605;&#1588;&#1705;&#1604; &#1576;&#1585;&#1582;&#1608;&#1585;&#1583; &#1605;&#1740; &#1705;&#1606;&#1583;. &#1575;&#1711;&#1585; &#1583;&#1585; &#1608;&#1576; &#1587;&#1575;&#1740;&#1578; &#1576;&#1607; &#1605;&#1588;&#1705;&#1604; &#1576;&#1585;&#1582;&#1608;&#1585;&#1583; &#1705;&#1585;&#1583;&#1740;&#1583; &#1608; &#1601;&#1585;&#1605; &#1607;&#1575; &#1608; &#1605;&#1608;&#1575;&#1585;&#1583; &#1605;&#1585;&#1576;&#1608;&#1591; &#1576;&#1607; &#1583;&#1575;&#1588;&#1576;&#1585;&#1583; &#1588;&#1705;&#1604; &#1606;&#1575; &#1605;&#1606;&#1575;&#1587;&#1576;&#1740; &#1662;&#1740;&#1583;&#1575; &#1705;&#1585;&#1583;&#1607; &#1575;&#1587;&#1578; &#1583;&#1585; &#1578;&#1606;&#1592;&#1740;&#1605;&#1575;&#1578; &#1585;&#1608;&#1740; &#1576;&#1604;&#1607; &#1602;&#1585;&#1575;&#1585; &#1583;&#1607;&#1740;&#1583;  
</div>   
    <?php echo JHtml::_('bootstrap.endTab'); ?>


    <?php echo JHtml::_('bootstrap.addTab', 'main', 'port_settings', JText::_('&#1578;&#1606;&#1592;&#1740;&#1605;&#1575;&#1578; &#1583;&#1585;&#1711;&#1575;&#1607; &#1607;&#1575;', true)); ?>
        <?php echo JHtml::_('bootstrap.startTabSet', 'sub_main', array('active' => 'saman')); ?>
 
            <?php echo JHtml::_('bootstrap.addTab', 'sub_main', 'saman', JText::_('&#1583;&#1585;&#1711;&#1575;&#1607; &#1587;&#1575;&#1605;&#1575;&#1606;', true)); ?>
            <h5> &#1601;&#1593;&#1575;&#1604; &#1576;&#1608;&#1583;&#1606; &#1583;&#1585;&#1711;&#1575;&#1607; </h5>
                        <input type="radio" name="active9" value="1" <? echo ($port_saman->active) == 1 ? 'checked="checked"' : ''; ?>> &#1576;&#1604;&#1607;
                        <input type="radio" name="active9" value="0"  <? echo ($port_saman->active) == 0 ? 'checked="checked"' : ''; ?>> &#1582;&#1740;&#1585;
                        <hr>
                         <h5>&#1588;&#1605;&#1575;&#1585;&#1607; &#1578;&#1585;&#1605;&#1740;&#1606;&#1575;&#1604; : </h5>
                      <input name="terminalcode9" id="terminalcode9" value="<? echo htmlspecialchars($port_saman->terminal_code, ENT_COMPAT, 'UTF-8'); ?>" class="required" required="required" aria-required="true" aria-invalid="false" type="text"><br>
            <?php echo JHtml::_('bootstrap.endTab'); ?>


            <?php echo JHtml::_('bootstrap.addTab', 'sub_main', 'mellat', JText::_('&#1583;&#1585;&#1711;&#1575;&#1607; &#1605;&#1604;&#1578; ', true)); ?>
                      <h5>&#1601;&#1593;&#1575;&#1604; &#1576;&#1608;&#1583;&#1606; &#1583;&#1585;&#1711;&#1575;&#1607; </h5>
                        <input type="radio" name="active1" value="1" <? echo ($port_mellat->active) == 1 ? 'checked="checked"' : ''; ?>> &#1576;&#1604;&#1607;

                        <input type="radio" name="active1" value="0" <? echo ($port_mellat->active) == 0 ? 'checked="checked"' : ''; ?>> &#1582;&#1740;&#1585;
                        <hr>
                        <h5>&#1606;&#1575;&#1605; &#1705;&#1575;&#1585;&#1576;&#1585;&#1740; : </h5>
                       <input name="username1" id="username1" value="<? echo htmlspecialchars($port_mellat->username, ENT_COMPAT, 'UTF-8'); ?>" class="required" required="required" aria-required="true" aria-invalid="false" type="text">
                       <h5>&#1705;&#1604;&#1605;&#1607; &#1593;&#1576;&#1608;&#1585; : </h5>
                         <input name="password1" id="password1" value="<? echo htmlspecialchars($port_mellat->password, ENT_COMPAT, 'UTF-8'); ?>" class="required" required="required" aria-required="true" aria-invalid="false" type="text"><br>
                      <h5>&#1588;&#1605;&#1575;&#1585;&#1607; &#1578;&#1585;&#1605;&#1740;&#1606;&#1575;&#1604; : </h5>
                      <input name="terminalcode1" id="terminalcode1" value="<? echo htmlspecialchars($port_mellat->terminal_code, ENT_COMPAT, 'UTF-8'); ?>" class="required" required="required" aria-required="true" aria-invalid="false" type="text"><br>
            <?php echo JHtml::_('bootstrap.endTab'); ?>


            <?php echo JHtml::_('bootstrap.addTab', 'sub_main', 'sn', JText::_('&#1583;&#1585;&#1711;&#1575;&#1607; &#1587;&#1575;&#1608;&#1575;&#1606;&#1608;', true)); ?>
                        <h5> &#1601;&#1593;&#1575;&#1604; &#1576;&#1608;&#1583;&#1606; &#1583;&#1585;&#1711;&#1575;&#1607; </h5>
                        <input type="radio" name="active3" value="1" <? echo ($port_sn->active) == 1 ? 'checked="checked"' : ''; ?>> &#1576;&#1604;&#1607;
                        <input type="radio" name="active3" value="0" <? echo ($port_sn->active) == 0 ? 'checked="checked"' : ''; ?>> &#1582;&#1740;&#1585;

                        <hr>

                           <h5>&#1601;&#1593;&#1575;&#1604; &#1576;&#1608;&#1583;&#1606; &#1584;&#1582;&#1740;&#1585;&#1607; &#1605;&#1608;&#1575;&#1585;&#1583; &#1575;&#1582;&#1578;&#1740;&#1575;&#1585;&#1740; &#1608;&#1576; &#1587;&#1585;&#1608;&#1740;&#1587; : </h5>  
                        <input type="radio" name="testmode3" value="1" <? echo ($port_sn->test_mode) == 1 ? 'checked="checked"' : ''; ?>> &#1576;&#1604;&#1607;
                        <input type="radio" name="testmode3" value="0" <? echo ($port_sn->test_mode) == 0 ? 'checked="checked"' : ''; ?>> &#1582;&#1740;&#1585;
                     
                     <h5>&#1588;&#1605;&#1575;&#1585;&#1607; &#1578;&#1585;&#1605;&#1740;&#1606;&#1575;&#1604; : </h5>
                      <input name="terminalcode3" id="terminalcode3" value="<? echo htmlspecialchars($port_sn->terminal_code, ENT_COMPAT, 'UTF-8'); ?>" class="required" required="required" aria-required="true" aria-invalid="false" type="text"><br>
            <?php echo JHtml::_('bootstrap.endTab'); ?>


        <?php echo JHtml::_('bootstrap.endTabSet'); ?>
    <?php echo JHtml::_('bootstrap.endTab'); ?>


<?php echo JHtml::_('bootstrap.endTabSet'); ?>
<input type="hidden" name="task" value="storepayment.edit" />
<?php echo JHtml::_('form.token'); ?>
</div>
</form>
<div class="clearfix"></div>
<div class="row-fluid margin">
<?php TinyPaymentHelper::cRight(); ?>
</div>