SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS `#__tinypayment_form_logs`;
DROP TABLE IF EXISTS `#__tinypayment_logs`; 
DROP TABLE IF EXISTS `#__tinypayment_msgs`;
DROP TABLE IF EXISTS `#__tinypayment_paymentinfo`;
DROP TABLE IF EXISTS `#__tinypayment_status_log`;
DROP TABLE IF EXISTS `#__tinypayment_transactions`;
DROP TABLE IF EXISTS `#__tinypayment_banks`;
DROP TABLE IF EXISTS `#__tinypayment_settings`;
